// test-client.js
const WebSocket = require('ws');

// Replace with your JWT token
const token = 'your-jwt-token-here';
const ws = new WebSocket('ws://localhost:8090/ws', ['Bearer ' + token]);

ws.on('open', () => {
    console.log('Connected to WebSocket server');

    // Send a ping message
    ws.send(JSON.stringify({ type: 'ping' }));
});

ws.on('message', (data) => {
    const message = JSON.parse(data);
    console.log('Received:', message);

    if (message.type === 'welcome') {
        console.log('Successfully authenticated as user:', message.userId);
    }
});

ws.on('close', () => {
    console.log('Disconnected from WebSocket server');
});

ws.on('error', (error) => {
    console.error('WebSocket error:', error.message);
});