import * as suggestHandler from './endpoints/wildberries/suggest.js';
import * as searchHandler from './endpoints/wildberries/search.js';
import * as productHandler from './endpoints/wildberries/product.js';
import * as brandHandler from './endpoints/wildberries/brand.js';
import * as sellerHandler from './endpoints/wildberries/seller.js';
import { logEvent } from './utils/logs.js';

export async function routeMessage(user, msg) {
  if (!msg || typeof msg !== 'object') throw new Error('invalid_message');
  const { source, type } = msg;
  if (source !== 'wildberries') throw new Error('unsupported_source');

  const requestId = msg.requestId || Date.now().toString(36);
  await logEvent(requestId, user?.id, 'route_start', { type, source });

  let res;
  switch (type) {
    case 'suggest':
      res = await suggestHandler.handle(requestId, user, msg);
      break;
    case 'search':
      res = await searchHandler.handle(requestId, user, msg);
      break;
    case 'product':
      res = await productHandler.handle(requestId, user, msg);
      break;
    case 'brand':
      res = await brandHandler.handle(requestId, user, msg);
      break;
    case 'seller':
      res = await sellerHandler.handle(requestId, user, msg);
      break;
    default:
      throw new Error('unsupported_type');
  }

  await logEvent(requestId, user?.id, 'route_done', { type, source });
  return { requestId, ...res };
}
