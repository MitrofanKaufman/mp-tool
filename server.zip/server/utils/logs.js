// server/utils/logs.js
import { knex } from './pool.js';

export async function logEvent(requestId, userId, event, context = {}) {
  await knex('logs').insert({
    request_id: requestId,
    user_id: userId || null,
    event,
    context: JSON.stringify(context)
  });
}