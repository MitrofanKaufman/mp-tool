/**
 * Main server entry point for the WebSocket API server
 * @module index
 */
require('dotenv').config();
const path = require('path');

// Initialize Fastify first
const fastify = require('fastify')({
  logger: {
    level: process.env.LOG_LEVEL || 'info',
    transport: {
      target: 'pino-pretty',
      options: {
        translateTime: 'HH:MM:ss Z',
        ignore: 'pid,hostname',
      },
    },
  },
  trustProxy: true,
});

// Register WebSocket support first
fastify.register(require('@fastify/websocket'), {
  options: {
    maxPayload: Number(process.env.WS_MAX_PAYLOAD) || 1048576,
    clientTracking: true,
  },
});

/* -------------------- Plugins -------------------- */
fastify.register(require('@fastify/cors'), {
  origin: process.env.CORS_ORIGIN ? process.env.CORS_ORIGIN.split(',') : true,
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  exposedHeaders: ['Content-Range', 'X-Total-Count'],
});

fastify.register(require('@fastify/helmet'), {
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'"],
    },
  },
});

fastify.register(require('@fastify/rate-limit'), {
  max: Number(process.env.RATE_LIMIT_MAX) || 100,
  timeWindow: process.env.RATE_LIMIT_WINDOW_MS || '15 minutes',
  allowList: ['127.0.0.1'],
  keyGenerator: (req) => req.headers['x-forwarded-for'] || req.ip,
});

/* -------------------- Routes & WebSocket -------------------- */
// Import the WebSocket plugin
const wsPlugin = require('./public/ws');
fastify.register(wsPlugin, { prefix: '/ws' });

// Register other routes
fastify.register(require('./public/admin'), { prefix: '/admin' });

/* -------------------- Swagger (only dev) -------------------- */
if (process.env.NODE_ENV !== 'production') {
  fastify.register(require('@fastify/swagger'), {
    routePrefix: '/docs',
    exposeRoute: true,
    swagger: {
      info: {
        title: 'WebSocket API Server',
        description: 'Real-time WebSocket API server',
        version: '1.0.0',
      },
      host: process.env.SWAGGER_HOST || `localhost:${process.env.PORT || 8090}`,
      schemes: ['http', 'https'],
      consumes: ['application/json'],
      produces: ['application/json'],
      tags: [
        { name: 'websocket', description: 'WebSocket endpoints' },
        { name: 'admin', description: 'Admin endpoints' },
      ],
    },
  });
}

/* -------------------- Health Check -------------------- */
fastify.get('/health', async () => ({
  status: 'ok',
  timestamp: new Date().toISOString(),
  uptime: process.uptime(),
  connections: fastify.websocketServer?.clients?.size || 0,
}));

/* -------------------- Start Server -------------------- */
const start = async () => {
  try {
    const port = Number(process.env.PORT) || 8090;
    await fastify.listen({ port, host: '0.0.0.0' });
    fastify.log.info(`Server listening on port ${port}`);
  } catch (err) {
    fastify.log.error(err);
    process.exit(1);
  }
};

['SIGTERM', 'SIGINT'].forEach(signal => {
  process.on(signal, async () => {
    fastify.log.info(`${signal} received. Shutting down gracefully...`);
    fastify.websocketServer?.clients?.forEach(client => client.close());
    await fastify.close();
    process.exit(0);
  });
});

if (require.main === module) start();

module.exports = fastify;