import { Page } from 'playwright';
import selectorMap from '../map.json';
import { logger } from '../utils/logger';

export async function getSellerDetails(page: Page, result: any, execution: any): Promise<void> {
  try {
    const selectors = selectorMap.getSellerDetails.split(',');
    for (const selector of selectors) {
      const element = await page.$(selector.trim());
      if (element) {
        const text = await element.textContent();
        if (text) {
          result.details = text.trim();
          logger.logSelectorIssue(result.id, selector, 'sellerDetails');
          logger.logStepSuccess('sellerDetails', result.id);
          return;
        }
      }
    }
    result.details = null;
    logger.logSelectorIssue(result.id, 'all sellerDetails selectors', 'sellerDetails');
  } catch (error) {
    logger.logStepError('sellerDetails', result.id, error as Error);
    throw new Error(`Ошибка получения детальной информации о продавце: ${error}`);
  }
}
