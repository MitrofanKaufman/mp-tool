import { Page } from 'playwright';
import selectorMap from '../map.json';
import { logger } from '../utils/logger';

export async function getSellerSales(page: Page, result: any, execution: any): Promise<void> {
  try {
    const selectors = selectorMap.getSellerSales.split(',');
    for (const selector of selectors) {
      const element = await page.$(selector.trim());
      if (element) {
        const text = await element.textContent();
        if (text) {
          result.sales = text.trim();
          logger.logSelectorIssue(result.id, selector, 'sellerSales');
          logger.logStepSuccess('sellerSales', result.id);
          return;
        }
      }
    }
    result.sales = null;
    logger.logSelectorIssue(result.id, 'all sellerSales selectors', 'sellerSales');
  } catch (error) {
    logger.logStepError('sellerSales', result.id, error as Error);
    throw new Error(`Ошибка получения данных о продажах продавца: ${error}`);
  }
}
