import { Page } from 'playwright';
import selectorMap from '../map.json';
import { logger } from '../utils/logger';

export async function getSellerStats(page: Page, result: any, execution: any): Promise<void> {
  try {
    const ratingSelectors = selectorMap.getSellerStatsRating.split(',');
    for (const selector of ratingSelectors) {
      const element = await page.$(selector.trim());
      if (element) {
        const text = await element.textContent();
        if (text) {
          result.rating = text.trim();
          logger.logSelectorIssue(result.id, selector, 'sellerStatsRating');
          break;
        }
      }
    }
    const reviewSelectors = selectorMap.getSellerStatsReviews.split(',');
    for (const selector of reviewSelectors) {
      const element = await page.$(selector.trim());
      if (element) {
        const text = await element.textContent();
        if (text) {
          result.reviews = text.trim();
          logger.logSelectorIssue(result.id, selector, 'sellerStatsReviews');
          break;
        }
      }
    }
    logger.logStepSuccess('sellerStats', result.id);
  } catch (error) {
    logger.logStepError('sellerStats', result.id, error as Error);
    throw new Error(`Ошибка получения статистики продавца: ${error}`);
  }
}
