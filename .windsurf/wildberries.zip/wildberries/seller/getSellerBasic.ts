import { Page } from 'playwright';
import selectorMap from '../map.json';
import { logger } from '../utils/logger';

export async function getSellerBasic(page: Page, result: any, execution: any): Promise<void> {
  try {
    const selectors = selectorMap.getSellerBasic.split(',');
    for (const selector of selectors) {
      const element = await page.$(selector.trim());
      if (element) {
        const text = await element.textContent();
        if (text) {
          result.basicInfo = text.trim();
          logger.logSelectorIssue(result.id, selector, 'sellerBasic');
          logger.logStepSuccess('sellerBasic', result.id);
          return;
        }
      }
    }
    result.basicInfo = null;
    logger.logSelectorIssue(result.id, 'all sellerBasic selectors', 'sellerBasic');
  } catch (error) {
    logger.logStepError('sellerBasic', result.id, error as Error);
    throw new Error(`Ошибка получения базовой информации о продавце: ${error}`);
  }
}
