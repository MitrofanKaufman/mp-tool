import fs from 'fs';
import path from 'path';

/**
 * Сохраняет данные в JSON файл
 * @param {string} type - тип данных (products, sellers и т.д.)
 * @param {string} id - ID объекта
 * @param {object} data - данные для сохранения
 * @returns {Promise<boolean>} - результат операции
 */
export async function saveJson(type: string, id: string, data: object): Promise<boolean> {
  try {
    const dataDir = path.resolve(process.cwd(), 'data', type);
    fs.mkdirSync(dataDir, { recursive: true });

    const filename = `${id}.json`;
    const filepath = path.join(dataDir, filename);

    const jsonData = {
      ...data,
      scrapedAt: new Date().toISOString(),
      version: '1.0'
    };

    fs.writeFileSync(filepath, JSON.stringify(jsonData, null, 2), 'utf8');
    console.log(`💾 Данные сохранены: ${filepath}`);

    return true;
  } catch (error) {
    console.error(`❌ Ошибка сохранения ${type}/${id}:`, (error as Error).message);
    return false;
  }
}

/**
 * Загружает данные из JSON файла
 * @param {string} type - тип данных
 * @param {string} id - ID объекта
 * @returns {object|null} - загруженные данные или null
 */
export function loadJson(type: string, id: string): object | null {
  try {
    const dataDir = path.resolve(process.cwd(), 'data', type);
    const filename = `${id}.json`;
    const filepath = path.join(dataDir, filename);

    if (!fs.existsSync(filepath)) {
      return null;
    }

    const rawData = fs.readFileSync(filepath, 'utf8');
    const data = JSON.parse(rawData);

    return data;
  } catch (error) {
    console.error(`❌ Ошибка загрузки ${type}/${id}:`, (error as Error).message);
    return null;
  }
}
