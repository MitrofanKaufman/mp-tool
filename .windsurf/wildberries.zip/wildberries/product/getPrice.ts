import { Scraper } from '@/pages/ScraperCheck/scraper';
import selectorMap from '../map.json';
import { logger } from '../utils/logger';

/**
 * Извлекает числовое значение из текста цены
 */
function extractPriceValue(text: string): { value: number | null; text: string } {
  if (!text) return { value: null, text: 'Цена не найдена' };
  
  // Удаляем все нецифровые символы, кроме запятых и точек
  const cleanText = text.trim()
    .replace(/[^\d,.\s]/g, '')  // Оставляем только цифры, запятые, точки и пробелы
    .replace(/\s+/g, '')         // Удаляем все пробелы
    .replace(/,/g, '.');          // Заменяем запятые на точки
  
  // Ищем первое число с плавающей точкой
  const priceMatch = cleanText.match(/(\d+(?:\.\d+)?)/);
  
  if (priceMatch) {
    return {
      value: parseFloat(priceMatch[1]),
      text: text.trim()
    };
  }
  
  return { value: null, text: text.trim() || 'Некорректный формат цены' };
}

export async function getPrice(scraper: Scraper, settings: any, messages: any, result: any, execution: any): Promise<void> {
  try {
    const selectors = selectorMap.getPrice
      .split(',')
      .map(s => s.trim())
      .filter(s => s.length > 0);
    
    for (const selector of selectors) {
      try {
        const text = await scraper.getText(selector);
        if (text && text.trim().length > 0) {
          const { value, text: priceText } = extractPriceValue(text);
          
          if (value !== null) {
            result.price = value;
            result.priceText = priceText;
            logger.logSelectorIssue(result.id, selector, 'price');
            logger.logStepSuccess('price', result.id);
            return;
          }
        }
      } catch (error) {
        // Пропускаем ошибки отдельных селекторов, пробуем следующий
        logger.info(`Селектор не сработал: ${selector}`, { error: (error as Error).message });
      }
    }
    
    // Если дошли сюда - цена не найдена
    result.price = null;
    result.priceText = 'Цена не найдена';
    logger.logSelectorIssue(result.id, 'all price selectors', 'price');
    
  } catch (error) {
    logger.logStepError('price', result.id, error as Error);
    throw new Error(`Ошибка получения цены товара: ${error}`);
  }
}
