import { Scraper } from '@/pages/ScraperCheck/scraper';
import selectorMap from '../map.json';
import { logger } from '../utils/logger';

export async function getProductParameters(scraper: Scraper, settings: any, messages: any, result: any, execution: any): Promise<void> {
  try {
    const selectors = selectorMap.getProductParameters.split(',');
    for (const selector of selectors) {
      const text = await scraper.getText(selector.trim());
      if (text) {
        result.productParameters = text;
        logger.logSelectorIssue(result.id, selector, 'productParameters');
        logger.logStepSuccess('productParameters', result.id);
        return;
      }
    }
    result.productParameters = null;
    logger.logSelectorIssue(result.id, 'all productParameters selectors', 'productParameters');
  } catch (error) {
    logger.logStepError('productParameters', result.id, error as Error);
    throw new Error(`Ошибка получения параметров товара: ${error}` );
  }
}
