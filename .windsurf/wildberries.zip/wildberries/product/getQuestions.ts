import { Scraper } from '@/pages/ScraperCheck/scraper';
import selectorMap from '../map.json';
import { logger } from '../utils/logger';

export async function getQuestions(scraper: Scraper, settings: any, messages: any, result: any, execution: any): Promise<void> {
  try {
    const selectors = selectorMap.getQuestions.split(',');
    for (const selector of selectors) {
      const text = await scraper.getText(selector.trim());
      if (text) {
        result.questions = text;
        logger.logSelectorIssue(result.id, selector, 'questions');
        logger.logStepSuccess('questions', result.id);
        return;
      }
    }
    result.questions = null;
    logger.logSelectorIssue(result.id, 'all questions selectors', 'questions');
  } catch (error) {
    logger.logStepError('questions', result.id, error as Error);
    throw new Error(`Ошибка получения вопросов товара: ${error}` );
  }
}
