import { Scraper } from '@/pages/ScraperCheck/scraper';
import selectorMap from '../map.json';
import { logger } from '../utils/logger';

export async function getTitle(scraper: Scraper, settings: any, messages: any, result: any, execution: any): Promise<void> {
  try {
    const selectors = selectorMap.getTitle.split(',');
    for (const selector of selectors) {
      const text = await scraper.getText(selector.trim());
      if (text) {
        result.title = text;
        logger.logSelectorIssue(result.id, selector, 'title');
        logger.logStepSuccess('title', result.id);
        return;
      }
    }
    result.title = null;
    logger.logSelectorIssue(result.id, 'all title selectors', 'title');
  } catch (error) {
    logger.logStepError('title', result.id, error as Error);
    throw new Error(`Ошибка получения заголовка товара: ${error}` );
  }
}
