import { Scraper } from '@/pages/ScraperCheck/scraper';
import selectorMap from '../map.json';
import { logger } from '../utils/logger';

export async function getRatingAndReviews(scraper: Scraper, settings: any, messages: any, result: any, execution: any): Promise<void> {
  try {
    const ratingSelectors = selectorMap.getRating.split(',');
    for (const selector of ratingSelectors) {
      const text = await scraper.getText(selector.trim());
      if (text) {
        result.rating = text;
        logger.logSelectorIssue(result.id, selector, 'rating');
        break;
      }
    }
    const reviewSelectors = selectorMap.getReviews.split(',');
    for (const selector of reviewSelectors) {
      const text = await scraper.getText(selector.trim());
      if (text) {
        result.reviews = text;
        logger.logSelectorIssue(result.id, selector, 'reviews');
        break;
      }
    }
    logger.logStepSuccess('ratingAndReviews', result.id);
  } catch (error) {
    logger.logStepError('ratingAndReviews', result.id, error as Error);
    throw new Error(`Ошибка получения рейтинга и отзывов: ${error}` );
  }
}
