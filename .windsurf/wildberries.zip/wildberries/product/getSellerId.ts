import { Scraper } from '@/pages/ScraperCheck/scraper';
import selectorMap from '../map.json';
import { logger } from '../utils/logger';

export async function getSellerId(scraper: Scraper, settings: any, messages: any, result: any, execution: any): Promise<string | null> {
  try {
    const page = scraper.getPage();
    if (!page) throw new Error('Страница не инициализирована');

    const selectors = selectorMap.getSellerId.split(',');
    for (const selector of selectors) {
      const sellerElement = await page.$(selector.trim());
      if (sellerElement) {
        logger.logSelectorIssue(result.id, selector, 'sellerId');
        const sellerLink = await sellerElement.$('a[href*="/seller/"]');
        if (sellerLink) {
          const href = await sellerLink.getAttribute('href');
          if (href) {
            const sellerIdMatch = href.match(/\/seller\/(\d+)/);
            if (sellerIdMatch) {
              const sellerId = sellerIdMatch[1];
              logger.info(`Найден ID продавца для товара ${result.id}`, { sellerId });
              return sellerId;
            }
          }
        }
      }
    }
    logger.logSelectorIssue(result.id, 'all sellerId selectors', 'sellerId');
    return null;
  } catch (error) {
    logger.logStepError('sellerId', result.id, error as Error);
    throw new Error(`Ошибка получения ID продавца: ${error}` );
  }
}
