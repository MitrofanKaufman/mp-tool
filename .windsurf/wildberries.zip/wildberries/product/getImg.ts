import { Scraper } from '@/pages/ScraperCheck/scraper';
import selectorMap from '../map.json';
import { logger } from '../utils/logger';

export async function getImg(scraper: Scraper, settings: any, messages: any, result: any, execution: any): Promise<void> {
  try {
    const selectors = selectorMap.getImg.split(',');
    for (const selector of selectors) {
      const src = await scraper.getAttribute(selector.trim(), 'src');
      if (src) {
        result.img = src;
        logger.logSelectorIssue(result.id, selector, 'img');
        logger.logStepSuccess('img', result.id);
        return;
      }
    }
    result.img = null;
    logger.logSelectorIssue(result.id, 'all img selectors', 'img');
  } catch (error) {
    logger.logStepError('img', result.id, error as Error);
    throw new Error(`Ошибка получения изображения товара: ${error}` );
  }
}
