import { Scraper } from '@/pages/ScraperCheck/scraper';
import selectorMap from '../map.json';
import { logger } from '../utils/logger';

export async function getOriginalMark(scraper: Scraper, settings: any, messages: any, result: any, execution: any): Promise<void> {
  try {
    const selectors = selectorMap.getOriginalMark.split(',');
    for (const selector of selectors) {
      const text = await scraper.getText(selector.trim());
      if (text) {
        result.originalMark = text;
        logger.logSelectorIssue(result.id, selector, 'originalMark');
        logger.logStepSuccess('originalMark', result.id);
        return;
      }
    }
    result.originalMark = null;
    logger.logSelectorIssue(result.id, 'all originalMark selectors', 'originalMark');
  } catch (error) {
    logger.logStepError('originalMark', result.id, error as Error);
    throw new Error(`Ошибка получения отметки оригинальности: ${error}` );
  }
}
