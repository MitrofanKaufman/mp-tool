export * from './getImg';
export * from './getOriginalMark';
export * from './getPrice';
export * from './getProductParameters';
export * from './getQuestions';
export * from './getRatingAndReviews';
export * from './getSellerId';
export * from './getTitle';
