import { Page, Browser, chromium } from 'playwright';

export class Scraper {
  private page: Page | null = null;
  private browser: Browser | null = null;
  private debug: boolean;

  constructor(debug: boolean = true) {
    this.debug = debug;
  }

  private log(...args: any[]) {
    if (this.debug) {
      console.log('[Scraper]', ...args);
    }
  }

  async init() {
    try {
      this.log('Launching browser...');
      this.browser = await chromium.launch({ 
        headless: false, // Set to false to see the browser
        slowMo: 100,     // Slow down by 100ms for better debugging
      });
      
      const context = await this.browser.newContext({
        viewport: { width: 1280, height: 800 },
        userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
      });
      
      this.page = await context.newPage();
      this.log('Browser launched successfully');
    } catch (error) {
      this.log('Error initializing browser:', error);
      throw error;
    }
  }

  async goto(url: string, maxRetries: number = 3) {
    if (!this.page) throw new Error('Page not initialized');
    
    let lastError: Error | null = null;
    
    // Retry logic
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        this.log(`[Attempt ${attempt}/${maxRetries}] Navigating to: ${url}`);
        
        // Add a small delay between retries
        if (attempt > 1) {
          const delay = Math.min(1000 * attempt, 5000); // Max 5 seconds delay
          this.log(`Waiting ${delay}ms before retry...`);
          await new Promise(resolve => setTimeout(resolve, delay));
        }
        
        // Try to navigate with a reasonable timeout
        const navigationPromise = this.page.goto(url, { 
          waitUntil: 'domcontentloaded',
          timeout: 30000, // 30 seconds timeout per attempt
          referer: 'https://www.wildberries.ru/',
          headers: {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Cache-Control': 'no-cache',
            'Pragma': 'no-cache'
          }
        });
        
        // Add an additional timeout to the navigation
        const timeoutPromise = new Promise((_, reject) => 
          setTimeout(() => reject(new Error('Navigation timeout')), 40000)
        );
        
        await Promise.race([navigationPromise, timeoutPromise]);
        
        // Wait for the page to be interactive
        await this.page.waitForLoadState('domcontentloaded');
        await this.page.waitForLoadState('load');
        
        // Wait for a short time to ensure all dynamic content is loaded
        await this.page.waitForTimeout(2000);
        
        // Take a screenshot for debugging
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const screenshotPath = `debug-screenshot-${timestamp}.png`;
        await this.page.screenshot({ path: screenshotPath, fullPage: true });
        this.log(`Screenshot saved as ${screenshotPath}`);
        
        // Check if we're on a captcha page
        const isCaptcha = await this.page.$('div.CheckboxCaptcha') !== null;
        if (isCaptcha) {
          throw new Error('Captcha detected. Please try again later.');
        }
        
        this.log('Page loaded successfully');
        return; // Success!
        
      } catch (error) {
        lastError = error as Error;
        this.log(`Attempt ${attempt} failed:`, error);
        
        // If we get a captcha, no point in retrying
        if (error instanceof Error && error.message.includes('Captcha')) {
          throw error;
        }
        
        // Refresh the page on timeout
        if (this.page) {
          try {
            await this.page.reload({ waitUntil: 'domcontentloaded' });
          } catch (e) {
            // Ignore reload errors
          }
        }
      }
    }
    
    // If we get here, all retries failed
    throw new Error(`Failed to load page after ${maxRetries} attempts: ${lastError?.message}`);
  }

  getPage(): Page {
    if (!this.page) throw new Error('Page not initialized');
    return this.page;
  }

  async getText(selector: string): Promise<string | null> {
    if (!this.page) throw new Error('Page not initialized');
    
    try {
      this.log(`Getting text for selector: ${selector}`);
      
      // Wait for the selector to be visible
      await this.page.waitForSelector(selector, { 
        state: 'attached',
        timeout: 10000 // 10 seconds
      }).catch(() => {
        this.log(`Selector not found: ${selector}`);
        return null;
      });
      
      const el = await this.page.$(selector);
      if (!el) {
        this.log(`Element not found for selector: ${selector}`);
        return null;
      }
      
      const text = await el.textContent();
      const result = text ? text.trim() : null;
      this.log(`Text for ${selector}:`, result);
      return result;
      
    } catch (error) {
      this.log(`Error getting text for selector ${selector}:`, error);
      return null;
    }
  }

  async getAttribute(selector: string, attr: string): Promise<string | null> {
    if (!this.page) throw new Error('Page not initialized');
    
    try {
      this.log(`Getting attribute ${attr} for selector: ${selector}`);
      
      // Wait for the selector to be visible
      await this.page.waitForSelector(selector, { 
        state: 'attached',
        timeout: 10000 // 10 seconds
      }).catch(() => {
        this.log(`Selector not found: ${selector}`);
        return null;
      });
      
      const el = await this.page.$(selector);
      if (!el) {
        this.log(`Element not found for selector: ${selector}`);
        return null;
      }
      
      const attrValue = await el.getAttribute(attr);
      const result = attrValue ? attrValue.trim() : null;
      this.log(`Attribute ${attr} for ${selector}:`, result);
      return result;
      
    } catch (error) {
      this.log(`Error getting attribute ${attr} for selector ${selector}:`, error);
      return null;
    }
  }

  async close() {
    try {
      if (this.browser) {
        this.log('Closing browser...');
        await this.browser.close();
        this.log('Browser closed');
      }
    } catch (error) {
      console.error('Error closing browser:', error);
    }
  }
}
