// src/server/wildberries/handler.ts
import { ApiRequest, ApiResponse, ProductData } from '../common/types';
import { Scraper } from './scraper';
import * as productFunctions from './product';
import * as sellerFunctions from './seller';
import { logInfo, logError } from '../common/logger';
import { getFromDb, saveToDb } from '../common/db';

/**
 * Тип данных для отзывов согласно API спецификации
 */
interface ReviewData {
    user: string;
    rating: number;
    comment: string;
    date?: string;
}

/**
 * Тип данных для рейтинга согласно API спецификации
 */
interface RatingData {
    rating: number;
    reviews_count: number;
}

/**
 * Обработчик запросов для Wildberries с интеграцией мощного скрейпера
 */
export const handleRequest = async (req: ApiRequest): Promise<ApiResponse> => {
    const { type, id } = req;

    try {
        switch (type) {
            case 'product':
                return await getProduct(id);
            case 'reviews':
                return await getReviews(id);
            case 'rating':
                return await getRating(id);
            case 'db':
                const data = await getFromDb(id);
                return { success: true, data };
            default:
                return { success: false, error: 'Тип данных не поддерживается' };
        }
    } catch (error: any) {
        logError(`Ошибка обработки запроса Wildberries ${type}:${id}`, error);
        return { success: false, error: error.message };
    }
};

/**
 * Получение полных данных о продукте с кешированием
 */
const getProduct = async (id: string): Promise<ApiResponse<ProductData>> => {
    logInfo(`Запрос данных продукта WB: ${id}`);

    // Сначала проверяем кеш
    const cachedProduct = await getFromDb(id);
    if (cachedProduct) {
        logInfo(`Данные продукта взяты из кеша: ${id}`);
        return { success: true, data: cachedProduct };
    }

    // Если нет в кеше, загружаем с сайта используя мощный скрейпер
    logInfo(`Загружаем данные продукта с WB используя скрейпер: ${id}`);

    const scraper = new Scraper(true); // headless режим для сервера
    const result: any = { id };

    try {
        await scraper.init();
        const url = `https://www.wildberries.ru/catalog/${id}/detail.aspx`;
        await scraper.goto(url);

        // Выполняем все функции парсинга продукта
        for (const fnName of Object.keys(productFunctions)) {
            if (typeof productFunctions[fnName] === 'function' && !fnName.startsWith('_')) {
                try {
                    await productFunctions[fnName](scraper, {}, {}, result, {});
                } catch (e) {
                    logError(`Ошибка в функции ${fnName} для продукта ${id}`, e);
                }
            }
        }

        // Преобразуем результат в формат ProductData
        const product: ProductData = {
            id,
            name: result.title || 'Неизвестный товар',
            price: result.price ? parseFloat(result.price.replace(/\D/g, '')) : 0,
            rating: result.rating ? parseFloat(result.rating) : 0,
            reviews: result.reviewsCount ? parseInt(result.reviewsCount) : 0,
            category: result.category || undefined,
            brand: result.brand || undefined
        };

        // Сохраняем в кеш
        await saveToDb(product);

        await scraper.close();
        return { success: true, data: product };

    } catch (error: any) {
        await scraper.close();
        logError(`Ошибка загрузки продукта ${id}`, error);
        return { success: false, error: error.message };
    }
};

/**
 * Получение отзывов о продукте
 */
const getReviews = async (id: string): Promise<ApiResponse<ReviewData[]>> => {
    logInfo(`Запрос отзывов продукта WB: ${id}`);

    // В будущем здесь можно реализовать парсинг страницы отзывов
    // Пока возвращаем заглушку в правильном формате
    const reviews: ReviewData[] = [
        { user: "Иван", rating: 5, comment: "Отличный товар!", date: new Date().toISOString() },
        { user: "Мария", rating: 4, comment: "Хорошо, но цена высоковата", date: new Date().toISOString() }
    ];

    return { success: true, data: reviews };
};

/**
 * Получение рейтинга продукта
 */
const getRating = async (id: string): Promise<ApiResponse<RatingData>> => {
    logInfo(`Запрос рейтинга продукта WB: ${id}`);

    // Используем данные из кеша или скрейпера
    const cachedProduct = await getFromDb(id);
    if (cachedProduct) {
        const rating: RatingData = {
            rating: cachedProduct.rating || 0,
            reviews_count: cachedProduct.reviews || 0
        };
        return { success: true, data: rating };
    }

    // Заглушка для рейтинга
    const rating: RatingData = { rating: 4.5, reviews_count: 100 };
    return { success: true, data: rating };
};
