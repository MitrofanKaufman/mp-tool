/**
 * Сохраняет данные в JSON файл
 * @param {string} type - тип данных (products, sellers и т.д.)
 * @param {string} id - ID объекта
 * @param {object} data - данные для сохранения
 * @returns {Promise<boolean>} - результат операции
 */
export declare function saveJson(type: string, id: string, data: object): Promise<boolean>;
/**
 * Загружает данные из JSON файла
 * @param {string} type - тип данных
 * @param {string} id - ID объекта
 * @returns {object|null} - загруженные данные или null
 */
export declare function loadJson(type: string, id: string): object | null;
