/**
 * Настройки для скрапера товаров
 */
export default class Settings {
    scrapeTimeout: number;
    userAgent: string;
    browserArgs: string[];
    messages: Record<string, string>;
    constructor();
}
