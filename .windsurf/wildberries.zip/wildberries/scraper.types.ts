export interface ScraperOptions {
  headless?: boolean;
  retries?: number;
  delay?: number;
  logDir?: string;
  userAgent?: string;
  proxy?: string;
  timeout?: number;
}

export interface ProductData {
  title: string | null;
  price: string | null;
  rating: string | null;
  reviewsCount: string | null;
  image: string | null;
  description: string | null;
  url: string;
  timestamp: string;
}
