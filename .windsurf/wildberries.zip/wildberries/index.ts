import { Scraper } from './scraper';
import * as productFunctions from './product';
import * as sellerFunctions from './seller';
import selectorMap from './map.json';
import fs from 'fs/promises';
import path from 'path';

// Enable debug mode for more detailed logs
const DEBUG = true;

async function main() {
  console.log('Starting scraper...');
  const url = 'https://www.wildberries.ru/catalog/494419055/detail.aspx';
  const result: any = { id: 'product-494419055' };

  try {
    // Initialize scraper with debug mode
    const scraper = new Scraper(DEBUG);
    await scraper.init();

    console.log(`Navigating to product page: ${url}`);
    await scraper.goto(url);

    // Execute all product functions
    console.log('Executing product functions...');
    for (const fnName of Object.keys(productFunctions)) {
      if (typeof productFunctions[fnName] === 'function' && !fnName.startsWith('_')) {
        try {
          console.log(`\n--- Executing product function: ${fnName} ---`);
          await productFunctions[fnName](scraper, {}, {}, result, {});
          console.log(`✅ Function ${fnName} completed successfully`);
        } catch (e) {
          console.error(`❌ Error in function ${fnName}:`, e);
        }
      }
    }

    // Get seller ID for further scraping
    console.log('\n--- Processing seller information ---');
    let sellerId = result.sellerId;
    if (!sellerId && productFunctions.getSellerId) {
      console.log('Getting seller ID...');
      sellerId = await productFunctions.getSellerId(scraper, {}, {}, result, {});
      console.log('Seller ID:', sellerId);
    }

    if (sellerId) {
      const sellerUrl = `https://www.wildberries.ru/seller/${sellerId}`;
      console.log(`\nNavigating to seller page: ${sellerUrl}`);
      await scraper.goto(sellerUrl);

      // Execute all seller functions
      console.log('Executing seller functions...');
      for (const fnName of Object.keys(sellerFunctions)) {
        if (typeof sellerFunctions[fnName] === 'function' && !fnName.startsWith('_')) {
          try {
            console.log(`\n--- Executing seller function: ${fnName} ---`);
            await sellerFunctions[fnName](scraper.getPage(), result, {});
            console.log(`✅ Function ${fnName} completed successfully`);
          } catch (e) {
            console.error(`❌ Error in seller function ${fnName}:`, e);
          }
        }
      }
    } else {
      console.warn('No seller ID found, skipping seller page');
    }

    // Save results
    const outputPath = path.resolve(__dirname, 'result.json');
    await fs.writeFile(outputPath, JSON.stringify(result, null, 2));
    console.log('\n--- Results ---');
    console.log('Scraped data:', JSON.stringify(result, null, 2));
    console.log(`\n✅ Results saved to: ${outputPath}`);

  } catch (error) {
    console.error('\n❌ Fatal error in main process:', error);
    process.exit(1);
  } finally {
    // Ensure the browser is always closed
    if (scraper) {
      await scraper.close();
    }
  }
}

main().catch(console.error);
