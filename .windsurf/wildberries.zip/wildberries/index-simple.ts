// src/server/wildberries/index.ts
import { Request } from "express";

export async function fetchWildberriesData(req: Request) {
  const { type, id, filters } = req.body;

  // Простейший мок данных
  if (type === "product") {
    return { id, name: "Куртка демисезонная женская", price: 4999 };
  }
  if (type === "reviews") {
    return [
      { user: "Ivan", rating: 5, comment: "Отличная куртка!" },
      { user: "Anna", rating: 4, comment: "Хорошо, но немного тесновато." }
    ];
  }
  if (type === "rating") {
    return { id, rating: 4.7, reviews_count: 128 };
  }
  return { message: "Unknown type" };
}
