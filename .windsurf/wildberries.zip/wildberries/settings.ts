/**
 * Настройки для скрапера товаров
 */
export default class Settings {
  public scrapeTimeout: number;
  public userAgent: string;
  public browserArgs: string[];
  public messages: Record<string, string>;

  constructor() {
    this.scrapeTimeout = 30000;
    this.userAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';
    this.browserArgs = [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-blink-features=AutomationControlled',
      '--disable-web-security'
    ];

    this.messages = {
      getTitleError: 'Ошибка получения названия товара',
      getPriceError: 'Ошибка получения цены товара',
      getRatingError: 'Ошибка получения рейтинга товара',
      getQuestionsError: 'Ошибка получения вопросов о товаре',
      getImageError: 'Ошибка получения изображения товара',
      getParametersError: 'Ошибка получения характеристик товара',
      getOriginalMarkError: 'Ошибка проверки оригинальности товара',
      getSellerIdError: 'Ошибка получения ID продавца товара',
      getProductParametersError: 'Ошибка получения параметров товара'
    };
  }
}
